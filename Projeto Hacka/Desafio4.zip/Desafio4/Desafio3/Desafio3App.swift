//
//  Desafio3App.swift
//  Desafio3
//
//  Created by Turma02-28 on 26/08/24.
//

import SwiftUI

@main
struct Desafio3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
