//
//  Desafio_5App.swift
//  Desafio 5
//
//  Created by Turma02-28 on 27/08/24.
//

import SwiftUI

@main
struct Desafio_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
