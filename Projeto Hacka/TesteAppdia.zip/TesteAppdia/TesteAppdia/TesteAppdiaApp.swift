//
//  TesteAppdiaApp.swift
//  TesteAppdia
//
//  Created by Turma02-28 on 04/09/24.
//

import SwiftUI

@main
struct TesteAppdiaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
