
import SwiftUI
import MapKit
import Foundation

struct Location: Identifiable{
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    let flag: String
    let description: String
}

var arraymapa = [
    
    Location(name: "Brasil", coordinate: CLLocationCoordinate2D(latitude: -15.803731, longitude: -47.89),
              flag:
                "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/250px-Flag_of_Brazil.svg.png",
              description:
                ""
             )
    ]


struct ContentView: View {
    @StateObject var viewmodel = ViewModel()
        @State private var position = MapCameraPosition.region(MKCoordinateRegion(center:  CLLocationCoordinate2D(latitude:-7.777796 , longitude:-39.930052 ), span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)))
         
         @State private var locations = arraymapa[0]
         @State private var showingSheet: Bool = false
        var body: some View {
    

                    ZStack{
                        VStack{
                            VStack {
                                ZStack{
                                    Color(.white)
                                        .opacity(0.6)
                                        .ignoresSafeArea()
                                }
                                VStack{
                                    Text("Word map")
                                        .font(.title)
                                    Text(locations.name)
                                }
                            }
                            .frame(height: 100)
                    
                        Map(position: $position){
                            Annotation("",  coordinate: locations.coordinate){
                                Image(systemName: "signpost.right.fill")
                                    .foregroundColor(.black)
                                    .background(.white)
                                    .font(.title)
                                    .cornerRadius(3.0)
                                    .onTapGesture {
                                        showingSheet.toggle()
                                    }
                                    .sheet(isPresented: $showingSheet) {
                                        VStack{
                                            Text(locations.name)
                                                .font(.title)
                                                .fontWeight(.bold)
                                                .padding()
                                            AsyncImage(url: URL(string: locations.flag)){
                                                Image in Image
                                                    .resizable().frame(width: 360, height:240)
                                            } placeholder:{
                                                
                                            }
                                            Text(locations.description)
                                                .padding()
                                        }
                                    }
                            }
                        }
                        .ignoresSafeArea()
                        
                   
                        Spacer()
                            HStack{
                                ForEach(arraymapa) { location in
                                    Button(action: {
                                        locations = location
                                        position = MapCameraPosition.region(MKCoordinateRegion(center:  location.coordinate, span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)))
                                    }
                                    ){
                                        AsyncImage(url: URL(string: location.flag)){
                                            Image in Image
                                                .resizable()
                                                .frame(width: 120, height: 80)
                                            
                                        }placeholder: {
                                            Color.yellow
                                        }
                                    }
                                }
                                
                            }
                            .padding()
                        }
                    
                    
                }
       

        
        
        
        /* ZStack{
            LinearGradient(gradient: Gradient(colors: [.blue, .green]), startPoint: .top, endPoint: .bottom)
                        .ignoresSafeArea(.all)
            ScrollView{
                VStack {
                    ForEach(viewmodel.chars, id: \.self){ p in
                        VStack{
                            Text(p.nomeLocal!)
                                .font(.title)
                                .foregroundStyle(.white)
                            AsyncImage(url: URL(string: p.foto!)){
                                    Image in Image
                                    .resizable()
                              } placeholder: {
                                     Color.gray
                          }
                              .frame(width: 300, height: 200)
                              .cornerRadius(7)
                            HStack{
                                VStack{
                                    Text(p.telefone!)
                                        .font(.title2)
                                        Spacer()
                                   Text(p.categoria!)
                                        .font(.title)
                                }
                                Text(p.descricao!)
                                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                
                            }
                        }
                       
                        ForEach(p.horarioFuncionamento!, id: \.self) { p1 in
                        
                            HStack{
                                VStack{
                                    Text("\(String(describing: p1.dia1!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia2!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia3!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia4!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia5!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia6!))")
                                        .font(.title)
                                    Text("\(String(describing: p1.dia7!))")
                                        .font(.title)
                                    
                                }
                            }
                               
                        }
                        }
                        
                 }
        
            }
            .onAppear() {
                viewmodel.fetch()
            }
                
            
        }
         */
    }
}

#Preview {
    ContentView()
}
