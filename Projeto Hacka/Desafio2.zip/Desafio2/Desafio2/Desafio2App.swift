//
//  Desafio2App.swift
//  Desafio2
//
//  Created by Turma02-28 on 22/08/24.
//

import SwiftUI

@main
struct Desafio2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
