//
//  AvaliationView.swift
//  Place.io
//
//  Created by Turma02-7 on 09/09/24.
//

import SwiftUI

struct AvaliationView: View {
    
    @ObservedObject var viewModel = RatingViewModel()
    @State private var coment: String = ""
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack {
            Spacer()
            Text("Avalie")
                .font(.title)
                .padding()
            //viewModel.ratingModel.rating utilizar esta variável para puxar o rating
            HStack {
                ForEach(1...5, id: \.self) { index in
                        RatingButton(viewModel: viewModel, index: index)
                }
            }
            .padding()
            TextField("Comente sua experiência", text: $coment)
                .multilineTextAlignment(.center)
                .frame(width: 350, height: 100)
                .background(.orange)
                .cornerRadius(33)
            Button("Enviar") {
                dismiss()
            }
            .padding()
            
            Spacer()
        }
    }
}

#Preview {
    AvaliationView()
}
