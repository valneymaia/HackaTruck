////
////  FilterViewModel.swift
////  Place.io
////
////  Created by Turma02-Backup on 11/09/24.
////
//
//import Foundation
//
//class FilterViewModel: ObservableObject {
//    var viewModel = ViewModel()
//    
//    func filtrar(categoria: String, param: String){
//        switch categoria {
//            
//        case "type":
//            switch param {
//            case "restaurante":
//                <#code#>
//            default:
//                
//            }
//            
//        default:
//            return null
//        }
//    }
//}
