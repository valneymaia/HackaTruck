
//  InfoView.swift
//  Place.io
//
//  Created by Turma02-Backup on 05/09/24.
//

import SwiftUI

struct InfoView: View {
    @StateObject var viewmodel = ViewModel()
    @State var nomelocal: String = ""
 
    var body: some View {
        NavigationStack {
            ScrollView {
                ForEach(viewmodel.chars.filter { $0.nomeLocal == nomelocal}, id: \.self){ p in
                  
                   
                VStack {
                        AsyncImage(url: URL(string: p.foto!)){ result in
                            result.image?
                                .resizable()
                        }
                        .cornerRadius(10)
                        .frame(width: 300, height: 300)
                        .padding(.top)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text(p.nomeLocal!)
                            .font(.title)
                            .padding()
                        
                        HStack {
                            Text(p.categoria!)
                                .bold()
                                .padding()
                            
                           
                                
                                HStack {
                                    
                                    ForEach(p.coment!, id: \.self){p2 in
                                        Text("\(p2.umAval!)" + " / 5.0")
                                            .padding(.leading)
                                        Image(systemName: "star.fill")
                                            .foregroundColor(.orange)
                                    }
                                    Text("\(p.nava!)")
                                        .padding(.leading)
                                
                                }
                            
                        }
                  
                        Divider()
                        
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                                .font(.title3)
                                .foregroundColor(.orange)
                            Text(p.endereco!)
                        }
                        Divider()
                    }
                    HStack {
                        Image(systemName: "info.bubble")
                            .foregroundColor(.orange)
                        Text(p.descricao!)
                        Spacer()
                    }
                    Divider()
                    HStack {
                        Image(systemName: "phone.fill")
                            .foregroundColor(.orange)
                        Text(p.telefone!)
                        Spacer()
                    }
                    Divider()
                    
                    ForEach(p.horarioFuncionamento!, id: \.self){p1 in
                        HStack {
                            Image(systemName: "calendar.badge.clock")
                                .font(.title3)
                                .foregroundColor(.orange)
                            ScrollView(.horizontal) {
                                VStack{
                                    HStack{
                                        Text(p1.dia1!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia2!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia3!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia4!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia5!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia6!)
                                        Spacer()
                                    }
                                    HStack{
                                        Text(p1.dia7!)
                                        Spacer()
                                    }
                                    
                                }
                            }
                        }
                        Divider()
                        
                        HStack{
                            NavigationLink(destination: CommentsView()) {
                                Text("Comentários / Avaliar")
                                    .padding()
                            }
                            .padding(.top)
                            .padding(.leading, 80)
                            Spacer()
                        }
                    }
                }
                
            }
            // .padding(.leading)
        }
        .onAppear() {
            viewmodel.fetch()
        }
    }
}
#Preview {
    InfoView(nomelocal: String("name"))
}
