//
//  Place_ioApp.swift
//  Place.io
//
//  Created by Turma02-Backup on 05/09/24.
//

import SwiftUI

@main
struct Place_ioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
