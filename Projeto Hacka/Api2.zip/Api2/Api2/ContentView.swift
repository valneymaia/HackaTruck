//
//  ContentView.swift
//  desafio api
//
//  Created by Turma02-28 on 30/08/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewmodel = ViewModel()
    var body: some View {
        ZStack{
            Color(.black)
                .ignoresSafeArea()
            ScrollView{
                VStack {
                    Text("Harry potter")
                        .background(.white)
                        .font(.title)
                    ForEach(viewmodel.chars){ p in
                        HStack{  
                            HStack{
                                AsyncImage(url: URL(string: p.image!)){
                                    Image in Image
                                        .resizable()
                                        .frame(width: 100, height: 100)
                                }placeholder:{
                                    
                                    Color.yellow
                                }
                                Spacer()
                            }
                            HStack{
                                Text(p.name!)
                                    .font(.title)
                                    .foregroundStyle(.white)
                                
                                Spacer()
                            }
                        }
                        
                    }
                    
                }
                .onAppear() {
                    viewmodel.fetch()
                }
                
            }
        }
        
    }
}

#Preview {
    ContentView()
}


