//
//  Api2App.swift
//  Api2
//
//  Created by Turma02-28 on 02/09/24.
//

import SwiftUI

@main
struct Api2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
