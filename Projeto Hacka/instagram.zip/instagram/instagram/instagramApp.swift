//
//  instagramApp.swift
//  instagram
//
//  Created by Turma02-28 on 21/08/24.
//

import SwiftUI

@main
struct instagramApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
