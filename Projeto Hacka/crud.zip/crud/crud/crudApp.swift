//
//  crudApp.swift
//  crud
//
//  Created by Turma02-28 on 03/09/24.
//

import SwiftUI

@main
struct crudApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
