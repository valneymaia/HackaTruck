//
//  Modo2View.swift
//  Desafio4-p2
//
//  Created by Turma02-28 on 26/08/24.
//

import SwiftUI

struct Modo2View: View {
    var body: some View {
        Text("2")
    }
}

#Preview {
    Modo2View()
}
