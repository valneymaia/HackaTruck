//
//  Modo1View.swift
//  Desafio4-p2
//
//  Created by Turma02-28 on 26/08/24.
//

import SwiftUI

struct Modo1View: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Modo1View()
}
