//
//  Desafio4_p2App.swift
//  Desafio4-p2
//
//  Created by Turma02-28 on 26/08/24.
//

import SwiftUI

@main
struct Desafio4_p2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
