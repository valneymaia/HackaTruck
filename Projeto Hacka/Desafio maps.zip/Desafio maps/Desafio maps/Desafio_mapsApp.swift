//
//  Desafio_mapsApp.swift
//  Desafio maps
//
//  Created by Turma02-28 on 29/08/24.
//

import SwiftUI

@main
struct Desafio_mapsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
